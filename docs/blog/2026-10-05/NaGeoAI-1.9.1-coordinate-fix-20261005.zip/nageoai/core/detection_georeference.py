"""Validate pixel detections and export RFC 7946 GeoJSON in EPSG:4326.

No QGIS imports: this module runs in the isolated GeoAI worker.
"""

import json
import math
from collections.abc import Mapping
from pathlib import Path
from uuid import uuid4


def write_georeferenced_detections(input_path, detections, output_path):
    import rasterio
    from rasterio.warp import transform_geom

    destination = Path(output_path)
    if destination.suffix.lower() != ".geojson":
        raise ValueError("객체탐지 출력은 .geojson 파일이어야 합니다.")
    if destination.exists():
        raise FileExistsError(f"Output already exists: {destination}")
    if not isinstance(detections, Mapping) or "boxes" not in detections:
        raise ValueError("탐지 모델이 boxes 결과를 반환하지 않았습니다.")
    boxes = detections["boxes"]
    if boxes is None:
        raise ValueError("탐지 boxes 결과가 None입니다.")
    scores = detections.get("scores", [None] * len(boxes))
    labels = detections.get("labels", [None] * len(boxes))
    if len(scores) != len(boxes) or len(labels) != len(boxes):
        raise ValueError("탐지 상자·점수·라벨의 개수가 일치하지 않습니다.")

    features = []
    large_boxes = 0
    clipped_boxes = 0
    with rasterio.open(input_path) as src:
        if src.crs is None:
            raise ValueError("입력 영상에 좌표계(CRS)가 없습니다.")
        if src.transform.is_identity or abs(src.transform.determinant) < 1e-15:
            raise ValueError("입력 영상에 유효한 픽셀→지도 좌표 변환이 없습니다.")
        source_crs = src.crs.to_string()
        for bbox, score, label in zip(boxes, scores, labels):
            if len(bbox) != 4:
                raise ValueError("탐지 상자는 x1,y1,x2,y2 형식이어야 합니다.")
            x1, y1, x2, y2 = [float(value) for value in bbox]
            if not all(math.isfinite(v) for v in (x1, y1, x2, y2)):
                raise ValueError("탐지 좌표에 NaN 또는 무한대가 있습니다.")
            if x2 <= x1 or y2 <= y1:
                raise ValueError("탐지 상자의 너비 또는 높이가 유효하지 않습니다.")
            clipped = (max(0.0, x1), max(0.0, y1),
                       min(float(src.width), x2), min(float(src.height), y2))
            clipped_boxes += int(clipped != (x1, y1, x2, y2))
            x1, y1, x2, y2 = clipped
            if x2 <= x1 or y2 <= y1:
                raise ValueError("탐지 상자가 입력 영상 범위 밖에 있습니다.")
            fraction = (x2 - x1) * (y2 - y1) / (src.width * src.height)
            large_boxes += int(fraction >= 0.8)
            # Transform every corner, including rotated/sheared rasters.
            ring = [list(src.transform * pixel) for pixel in
                    ((x1, y1), (x2, y1), (x2, y2), (x1, y2), (x1, y1))]
            geometry = transform_geom(src.crs, "EPSG:4326",
                                      {"type": "Polygon", "coordinates": [ring]})
            for longitude, latitude in geometry["coordinates"][0]:
                if not (math.isfinite(longitude) and math.isfinite(latitude)
                        and -180 <= longitude <= 180 and -90 <= latitude <= 90):
                    raise ValueError("변환된 경위도 좌표가 유효 범위를 벗어났습니다.")
            # RFC 7946 exterior rings use counterclockwise winding.
            geographic_ring = geometry["coordinates"][0]
            signed_area = sum(a[0] * b[1] - b[0] * a[1]
                              for a, b in zip(geographic_ring, geographic_ring[1:]))
            if signed_area < 0:
                geometry["coordinates"][0] = [geographic_ring[0],
                    *reversed(geographic_ring[1:-1]), geographic_ring[0]]
            numeric_score = None if score is None else float(score)
            if numeric_score is not None and not math.isfinite(numeric_score):
                raise ValueError("탐지 신뢰도에 NaN 또는 무한대가 있습니다.")
            features.append({"type": "Feature", "geometry": geometry,
                             "properties": {"score": numeric_score,
                                            "label": None if label is None else str(label),
                                            "image_fraction": fraction}})

    warnings = []
    if large_boxes:
        warnings.append(f"영상 면적의 80% 이상인 후보 {large_boxes}건: 오탐 여부를 검토하십시오.")
    if clipped_boxes:
        warnings.append(f"영상 경계를 벗어난 후보 {clipped_boxes}건을 경계로 잘랐습니다.")
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(f".{destination.name}.{uuid4().hex}.tmp")
    try:
        with temporary.open("x", encoding="utf-8") as stream:
            json.dump({"type": "FeatureCollection", "features": features},
                      stream, ensure_ascii=False, allow_nan=False)
        # Exclusive create: never replace another file produced during inference.
        with temporary.open("rb") as source, destination.open("xb") as target:
            import shutil
            shutil.copyfileobj(source, target)
    finally:
        temporary.unlink(missing_ok=True)
    return {"output": str(destination), "count": len(features),
            "source_crs": source_crs, "output_crs": "EPSG:4326",
            "warnings": warnings,
            "summary": f"객체탐지 후보 {len(features)}건 저장 (EPSG:4326). 정확도 검증 결과가 아닙니다."}

"""Fail-closed DeepForest pixel-to-map conversion using QGIS-bundled GDAL."""

import math


def read_georeference(image_path):
    from osgeo import gdal, osr

    if not image_path:
        raise ValueError("입력 영상 경로가 없어 좌표 변환을 수행할 수 없습니다.")
    dataset = gdal.Open(str(image_path), gdal.GA_ReadOnly)
    if dataset is None:
        raise ValueError("입력 영상을 열 수 없어 출력 저장을 중단합니다.")
    try:
        transform = dataset.GetGeoTransform(can_return_null=True)
        wkt = dataset.GetProjectionRef()
        if transform is None or not all(math.isfinite(v) for v in transform):
            raise ValueError("입력 영상에 유효한 픽셀→지도 좌표 변환이 없습니다.")
        determinant = transform[1] * transform[5] - transform[2] * transform[4]
        if determinant == 0:
            raise ValueError("입력 영상의 좌표 변환 행렬이 특이행렬입니다.")
        crs = osr.SpatialReference()
        if not wkt or crs.ImportFromWkt(wkt) != 0 or crs.Validate() != 0:
            raise ValueError("입력 영상에 유효한 좌표계(CRS)가 없습니다.")
        return transform, wkt, dataset.RasterXSize, dataset.RasterYSize
    finally:
        dataset = None


def pixel_box_ring(xmin, ymin, xmax, ymax, transform):
    """Transform all corners, preserving rotation and shear (not just bounds)."""
    xmin, ymin, xmax, ymax = map(float, (xmin, ymin, xmax, ymax))
    if not all(math.isfinite(v) for v in (xmin, ymin, xmax, ymax)):
        raise ValueError("탐지 좌표에 NaN 또는 무한대가 있습니다.")
    if xmax <= xmin or ymax <= ymin:
        raise ValueError("탐지 상자의 너비 또는 높이가 유효하지 않습니다.")
    ring = []
    for col, row in ((xmin, ymin), (xmax, ymin), (xmax, ymax),
                     (xmin, ymax), (xmin, ymin)):
        x = transform[0] + col * transform[1] + row * transform[2]
        y = transform[3] + col * transform[4] + row * transform[5]
        if not math.isfinite(x) or not math.isfinite(y):
            raise ValueError("변환된 지도 좌표가 유효하지 않습니다.")
        ring.append((x, y))
    return ring

"""Install and verify the optional OpenSR runtime used by NaGeoAI."""

from __future__ import annotations

import hashlib
import os
import subprocess
import sys
from pathlib import Path


PACKAGE_SPEC = "opensr-model==1.1.1"
CHECKPOINT_NAME = "opensr-ldsrs2_v1_0_0.ckpt"
CHECKPOINT_SIZE = 1_130_715_795
CHECKPOINT_SHA256 = "e2621e3912eb7c14867c3d20c9029607ba941be8e166dc09621860fcac27dc3a"
CHECKPOINT_URL = (
    "https://huggingface.co/simon-donike/RS-SR-LTDF/resolve/main/"
    + CHECKPOINT_NAME
)


def checkpoint_path() -> Path:
    """Match torch.hub's default cache without importing torch in QGIS."""
    root = os.environ.get("TORCH_HOME")
    if root:
        hub = Path(root).expanduser() / "hub"
    else:
        cache = os.environ.get("XDG_CACHE_HOME")
        hub = (Path(cache).expanduser() if cache else Path.home() / ".cache") / "torch" / "hub"
    return hub / "checkpoints" / CHECKPOINT_NAME


def package_installed(site_packages: str) -> bool:
    path = Path(site_packages)
    return (path / "opensr_model").is_dir() and any(
        path.glob("opensr_model-*.dist-info")
    )


def quick_status(site_packages: str) -> dict:
    """Cheap startup status; full checkpoint checksum is verified by installer."""
    path = checkpoint_path()
    marker = path.with_suffix(path.suffix + ".sha256")
    try:
        model_complete = (
            path.is_file()
            and path.stat().st_size == CHECKPOINT_SIZE
            and marker.is_file()
            and marker.read_text(encoding="ascii").strip() == CHECKPOINT_SHA256
        )
    except (OSError, UnicodeError):
        model_complete = False
    return {
        "package": package_installed(site_packages),
        "checkpoint": model_complete,
        "checkpoint_path": str(path),
    }


def _run_install(python_path, uv_path, progress, cancelled):
    if uv_path and Path(uv_path).is_file():
        command = [uv_path, "pip", "install", "--python", python_path, PACKAGE_SPEC]
    else:
        command = [python_path, "-m", "pip", "install", PACKAGE_SPEC]
    if progress:
        progress(55, "OpenSR 패키지 설치 중...")
    kwargs = {"stdout": subprocess.PIPE, "stderr": subprocess.STDOUT, "text": True,
              "encoding": "utf-8", "errors": "replace"}
    if sys.platform == "win32":
        kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    process = subprocess.Popen(command, **kwargs)
    try:
        while True:
            try:
                output, _ = process.communicate(timeout=0.5)
                break
            except subprocess.TimeoutExpired:
                if cancelled and cancelled():
                    process.terminate()
                    process.communicate()
                    raise RuntimeError("설치가 취소되었습니다")
        if process.returncode != 0:
            raise RuntimeError("OpenSR 패키지 설치 실패: " + output[-2000:])
    finally:
        if process.poll() is None:
            process.terminate()
            process.communicate()


def _verify_file(path: Path, progress=None, cancelled=None) -> bool:
    if not path.is_file() or path.stat().st_size != CHECKPOINT_SIZE:
        return False
    digest = hashlib.sha256()
    with path.open("rb") as source:
        while True:
            if cancelled and cancelled():
                raise RuntimeError("모델 검증이 취소되었습니다")
            chunk = source.read(8 * 1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    if digest.hexdigest() != CHECKPOINT_SHA256:
        return False
    marker = path.with_suffix(path.suffix + ".sha256")
    temporary = marker.with_suffix(marker.suffix + ".tmp")
    temporary.write_text(CHECKPOINT_SHA256 + "\n", encoding="ascii")
    temporary.replace(marker)
    if progress:
        progress(100, "OpenSR 모델 SHA-256 검증 완료")
    return True


def ensure_opensr_ready(
    python_path: str,
    site_packages: str,
    uv_path: str | None = None,
    progress=None,
    cancelled=None,
) -> tuple[bool, str]:
    """Install only missing components and download an integrity-checked model."""
    if sys.version_info < (3, 12):
        return False, "opensr-model 1.1.1에는 Python 3.12 이상이 필요합니다"
    if cancelled and cancelled():
        return False, "설치가 취소되었습니다"
    try:
        if not package_installed(site_packages):
            _run_install(python_path, uv_path, progress, cancelled)
            if not package_installed(site_packages):
                return False, "OpenSR 설치 후 패키지 확인에 실패했습니다"
        elif progress:
            progress(55, "OpenSR 패키지가 이미 설치되어 있어 건너뜁니다")

        path = checkpoint_path()
        if path.is_file():
            if progress:
                progress(60, "기존 OpenSR 모델 파일의 무결성 확인 중...")
            if _verify_file(path, progress, cancelled):
                return True, "OpenSR 패키지와 모델이 준비되었습니다 (기존 파일 재사용)"
            return False, f"기존 모델 파일의 크기 또는 SHA-256이 올바르지 않습니다: {path}"

        import requests

        path.parent.mkdir(parents=True, exist_ok=True)
        partial = path.with_suffix(path.suffix + ".part")
        if partial.exists():
            return False, f"미완료 다운로드 파일을 먼저 확인하십시오: {partial}"
        if progress:
            progress(61, "OpenSR 모델 다운로드 시작 (약 1.13 GB)...")
        try:
            with requests.get(CHECKPOINT_URL, stream=True, timeout=(30, 120)) as response:
                response.raise_for_status()
                received = 0
                with partial.open("xb") as output:
                    for chunk in response.iter_content(chunk_size=4 * 1024 * 1024):
                        if cancelled and cancelled():
                            raise RuntimeError("모델 다운로드가 취소되었습니다")
                        if chunk:
                            output.write(chunk)
                            received += len(chunk)
                            if progress:
                                progress(min(95, 61 + int(received * 34 / CHECKPOINT_SIZE)),
                                         f"OpenSR 모델 다운로드: {received / 1e9:.2f}/1.13 GB")
            if not _verify_file(partial, progress, cancelled):
                raise RuntimeError("다운로드한 모델의 크기 또는 SHA-256이 공식 파일과 다릅니다")
            partial.replace(path)
            partial.with_suffix(partial.suffix + ".sha256").replace(
                path.with_suffix(path.suffix + ".sha256")
            )
        except Exception:
            partial.unlink(missing_ok=True)
            partial.with_suffix(partial.suffix + ".sha256").unlink(missing_ok=True)
            raise
        return True, f"OpenSR 패키지와 모델 다운로드·검증 완료: {path}"
    except Exception as exc:
        return False, str(exc)

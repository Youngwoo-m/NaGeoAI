"""Blockwise, georeferenced two-date raster change detection."""

from __future__ import annotations

import json
import math
import os
from pathlib import Path


def detect_raster_change(
    before_path: str,
    after_path: str,
    output_raster: str,
    *,
    band: int = 1,
    method: str = "difference",
    threshold: float = 20.0,
    output_vector: str | None = None,
    progress=None,
) -> dict:
    """Create a binary change mask (1 changed, 0 unchanged, 255 NoData).

    Inputs must already be co-registered. ``difference`` uses the absolute
    pixel-value difference; ``normalized_difference`` uses
    ``abs(after-before)/(abs(after)+abs(before))``. The threshold is in the
    corresponding pixel-value or 0..1 units.
    """
    import numpy as np
    import rasterio
    from rasterio.features import shapes
    from rasterio.warp import transform_geom

    if method not in {"difference", "normalized_difference"}:
        raise ValueError("Unsupported change-detection method")
    if not math.isfinite(threshold) or threshold < 0:
        raise ValueError("Threshold must be a non-negative finite number")
    if method == "normalized_difference" and threshold > 1:
        raise ValueError("Normalized-difference threshold must be between 0 and 1")
    if band < 1:
        raise ValueError("Band number must be at least 1")

    source_paths = [Path(before_path).resolve(), Path(after_path).resolve()]
    for path in source_paths:
        if not path.is_file():
            raise FileNotFoundError(f"Input raster not found: {path}")
    raster_path = Path(output_raster).resolve()
    vector_path = Path(output_vector).resolve() if output_vector else None
    if raster_path.suffix.lower() not in {".tif", ".tiff"}:
        raise ValueError("Raster output must be a GeoTIFF (.tif)")
    if vector_path and vector_path.suffix.lower() != ".geojson":
        raise ValueError("Vector output must be GeoJSON (.geojson)")
    if raster_path in source_paths or vector_path in source_paths:
        raise ValueError("Output cannot overwrite an input raster")
    if vector_path == raster_path:
        raise ValueError("Raster and vector outputs must differ")
    if raster_path.exists() or (vector_path and vector_path.exists()):
        raise FileExistsError("Output already exists. Choose a different filename")

    with rasterio.open(source_paths[0]) as before, rasterio.open(source_paths[1]) as after:
        if before.crs is None or after.crs is None:
            raise ValueError("Both rasters require a coordinate reference system")
        if (before.width, before.height) != (after.width, after.height) or before.crs != after.crs or not before.transform.almost_equals(after.transform):
            raise ValueError("Rasters must have the same CRS, dimensions, and pixel grid. Align them in QGIS first")
        if band > min(before.count, after.count):
            raise ValueError("Selected band does not exist in both rasters")

        profile = before.profile.copy()
        profile.update(driver="GTiff", count=1, dtype="uint8", nodata=255, compress="lzw")
        raster_path.parent.mkdir(parents=True, exist_ok=True)
        changed = valid_count = 0
        try:
            with rasterio.open(raster_path, "w", **profile) as target:
                for _, window in before.block_windows(band):
                    first = before.read(band, window=window, masked=True).astype("float32")
                    second = after.read(band, window=window, masked=True).astype("float32")
                    valid = (~np.ma.getmaskarray(first)) & (~np.ma.getmaskarray(second))
                    a = np.ma.filled(first, np.nan)
                    b = np.ma.filled(second, np.nan)
                    valid &= np.isfinite(a) & np.isfinite(b)
                    if method == "difference":
                        magnitude = np.abs(b - a)
                    else:
                        denominator = np.abs(b) + np.abs(a)
                        magnitude = np.divide(np.abs(b - a), denominator, out=np.zeros_like(a), where=denominator > 0)
                    result = np.full(a.shape, 255, dtype=np.uint8)
                    result[valid] = (magnitude[valid] > threshold).astype(np.uint8)
                    target.write(result, 1, window=window)
                    changed += int(np.count_nonzero(result == 1))
                    valid_count += int(np.count_nonzero(valid))
            if progress:
                progress(f"Change mask saved: {raster_path}")

            polygon_count = 0
            if vector_path:
                vector_path.parent.mkdir(parents=True, exist_ok=True)
                # Stream polygons one raster block at a time to avoid loading
                # large scenes in memory. Polygons spanning blocks remain split.
                with rasterio.open(raster_path) as mask, vector_path.open("w", encoding="utf-8") as output:
                    output.write('{"type":"FeatureCollection","features":[')
                    first_feature = True
                    for _, window in mask.block_windows(1):
                        values = mask.read(1, window=window)
                        if not np.any(values == 1):
                            continue
                        for geometry, value in shapes(values, mask=values == 1, transform=mask.window_transform(window)):
                            if int(value) != 1:
                                continue
                            geometry = transform_geom(mask.crs, "EPSG:4326", geometry)
                            feature = {"type": "Feature", "properties": {"change": 1}, "geometry": geometry}
                            if not first_feature:
                                output.write(",")
                            json.dump(feature, output, ensure_ascii=False, separators=(",", ":"))
                            first_feature = False
                            polygon_count += 1
                    output.write("]}")
                if progress:
                    progress(f"Change polygons saved: {vector_path}")
        except Exception:
            raster_path.unlink(missing_ok=True)
            if vector_path:
                vector_path.unlink(missing_ok=True)
            raise

    return {
        "output_raster": str(raster_path),
        "output_vector": str(vector_path) if vector_path else "",
        "changed_pixels": changed,
        "valid_pixels": valid_count,
        "changed_percent": round(changed * 100 / valid_count, 2) if valid_count else 0.0,
        "polygon_count": polygon_count,
    }

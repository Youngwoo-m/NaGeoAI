"""QGIS panel for two-date raster change detection."""

from __future__ import annotations

import os

from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
from qgis.PyQt.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDockWidget,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)
from qgis.core import QgsProject, QgsRasterLayer, QgsVectorLayer


class ChangeDetectionWorker(QThread):
    completed = pyqtSignal(dict)
    failed = pyqtSignal(str)
    progress = pyqtSignal(str)

    def __init__(self, params):
        super().__init__()
        self.params = params

    def run(self):
        try:
            from ..core.geoai_task_subprocess import run_geoai_task

            result = run_geoai_task("detect_raster_change", self.params, self.progress.emit)
            self.completed.emit(result)
        except Exception as exc:
            self.failed.emit(str(exc))


class ChangeDetectionDockWidget(QDockWidget):
    """Compare one band of two co-registered raster scenes."""

    def __init__(self, iface, parent=None):
        super().__init__("NaGeoAI - 변화탐지", parent)
        self.iface = iface
        self.worker = None
        self.setAllowedAreas(Qt.DockWidgetArea.LeftDockWidgetArea | Qt.DockWidgetArea.RightDockWidgetArea)
        self._setup_ui()

    def _setup_ui(self):
        body = QWidget(self)
        layout = QVBoxLayout(body)
        form = QFormLayout()

        self.before = QLineEdit()
        self.after = QLineEdit()
        self.before.setPlaceholderText("이전 시기 GeoTIFF")
        self.after.setPlaceholderText("이후 시기 GeoTIFF")
        self.layers = QComboBox()
        self.refresh_button = QPushButton("레이어 새로 고침")
        self.refresh_button.clicked.connect(self._refresh_layers)
        layout.addWidget(QLabel("두 영상은 동일 좌표계·해상도·픽셀 격자로 정합되어 있어야 합니다."))
        layout.addWidget(self.refresh_button)
        for label, field in (("이전 영상", self.before), ("이후 영상", self.after)):
            row = QHBoxLayout()
            row.addWidget(field)
            browse = QPushButton("파일...")
            browse.clicked.connect(lambda _checked=False, target=field: self._browse_input(target))
            row.addWidget(browse)
            container = QWidget()
            container.setLayout(row)
            form.addRow(label, container)

        self.before_layer = QComboBox()
        self.after_layer = QComboBox()
        self.before_layer.currentIndexChanged.connect(lambda: self._select_layer(self.before_layer, self.before))
        self.after_layer.currentIndexChanged.connect(lambda: self._select_layer(self.after_layer, self.after))
        form.addRow("이전 레이어", self.before_layer)
        form.addRow("이후 레이어", self.after_layer)

        self.band = QComboBox()
        for number in range(1, 17):
            self.band.addItem(str(number), number)
        form.addRow("분석 밴드", self.band)
        self.method = QComboBox()
        self.method.addItem("절대 차분(원본 픽셀값)", "difference")
        self.method.addItem("정규화 차분(0~1)", "normalized_difference")
        self.method.currentIndexChanged.connect(self._method_changed)
        form.addRow("분석 방식", self.method)
        self.threshold = QDoubleSpinBox()
        self.threshold.setDecimals(4)
        self.threshold.setRange(0, 1000000)
        self.threshold.setValue(20)
        self.threshold.setToolTip("임계값보다 큰 픽셀을 변화로 분류합니다.")
        form.addRow("변화 임계값", self.threshold)
        self.raster = QLineEdit()
        self.raster.setPlaceholderText("변화 마스크 GeoTIFF 저장 경로")
        form.addRow("출력 래스터", self._output_row(self.raster, "GeoTIFF (*.tif)"))
        self.make_vector = QCheckBox("변화 폴리곤도 저장")
        form.addRow(self.make_vector)
        self.vector = QLineEdit()
        self.vector.setPlaceholderText("변화 폴리곤 GeoJSON 저장 경로")
        form.addRow("출력 벡터", self._output_row(self.vector, "GeoJSON (*.geojson)"))
        layout.addLayout(form)
        self.add_to_map = QCheckBox("결과를 지도에 추가")
        self.add_to_map.setChecked(True)
        layout.addWidget(self.add_to_map)
        self.run_button = QPushButton("변화탐지 실행")
        self.run_button.clicked.connect(self._run)
        layout.addWidget(self.run_button)
        self.log = QTextEdit()
        self.log.setReadOnly(True)
        layout.addWidget(self.log)
        self.setWidget(body)
        self._refresh_layers()

    def _output_row(self, field, filter_text):
        row = QHBoxLayout()
        row.addWidget(field)
        button = QPushButton("찾기...")
        button.clicked.connect(lambda: self._browse_output(field, filter_text))
        row.addWidget(button)
        container = QWidget()
        container.setLayout(row)
        return container

    def _refresh_layers(self):
        for combo in (self.before_layer, self.after_layer):
            selected = combo.currentData()
            combo.blockSignals(True)
            combo.clear()
            combo.addItem("레이어 선택...", None)
            for layer in QgsProject.instance().mapLayers().values():
                if isinstance(layer, QgsRasterLayer) and os.path.isfile(layer.source()):
                    combo.addItem(layer.name(), layer.source())
            if selected:
                index = combo.findData(selected)
                combo.setCurrentIndex(index if index >= 0 else 0)
            combo.blockSignals(False)

    def _select_layer(self, combo, field):
        path = combo.currentData()
        if path:
            field.setText(path)

    def _browse_input(self, field):
        path, _ = QFileDialog.getOpenFileName(self, "영상 선택", "", "Raster (*.tif *.tiff)")
        if path:
            field.setText(path)

    def _browse_output(self, field, filter_text):
        path, _ = QFileDialog.getSaveFileName(self, "출력 파일 저장", field.text(), filter_text)
        if path:
            field.setText(path)

    def _method_changed(self):
        normalized = self.method.currentData() == "normalized_difference"
        self.threshold.setRange(0, 1 if normalized else 1000000)
        self.threshold.setValue(0.2 if normalized else 20)

    def _run(self):
        before = self.before.text().strip()
        after = self.after.text().strip()
        raster = self.raster.text().strip()
        vector = self.vector.text().strip() if self.make_vector.isChecked() else None
        if not all((before, after, raster)) or (self.make_vector.isChecked() and not vector):
            QMessageBox.warning(self, "입력 확인", "이전·이후 영상과 출력 경로를 지정하십시오.")
            return
        if os.path.abspath(before) == os.path.abspath(after):
            QMessageBox.warning(self, "입력 확인", "서로 다른 두 시기의 영상을 지정하십시오.")
            return
        params = {
            "before_path": before,
            "after_path": after,
            "output_raster": raster,
            "output_vector": vector,
            "band": self.band.currentData(),
            "method": self.method.currentData(),
            "threshold": self.threshold.value(),
        }
        self.run_button.setEnabled(False)
        self.log.append("변화탐지를 시작합니다...")
        self.worker = ChangeDetectionWorker(params)
        self.worker.progress.connect(self.log.append)
        self.worker.completed.connect(self._completed)
        self.worker.failed.connect(self._failed)
        self.worker.start()

    def _completed(self, result):
        self.run_button.setEnabled(True)
        self.log.append(
            f"완료: 유효 픽셀 {result['valid_pixels']:,}개 중 변화 {result['changed_pixels']:,}개 "
            f"({result['changed_percent']:.2f}%)"
        )
        if self.add_to_map.isChecked():
            raster_layer = QgsRasterLayer(result["output_raster"], "NaGeoAI 변화 마스크")
            if raster_layer.isValid():
                QgsProject.instance().addMapLayer(raster_layer)
            if result.get("output_vector"):
                vector_layer = QgsVectorLayer(result["output_vector"], "NaGeoAI 변화 폴리곤", "ogr")
                if vector_layer.isValid():
                    QgsProject.instance().addMapLayer(vector_layer)

    def _failed(self, message):
        self.run_button.setEnabled(True)
        self.log.append(f"오류: {message}")
        QMessageBox.critical(self, "변화탐지 오류", message)

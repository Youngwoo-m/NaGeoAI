"""Additional GeoAI analysis and acquisition workflows for QGIS."""

from __future__ import annotations

import os

from qgis.PyQt.QtCore import Qt, QThread, pyqtSignal
from qgis.PyQt.QtWidgets import (
    QCheckBox, QComboBox, QDockWidget, QFileDialog, QFormLayout,
    QHBoxLayout, QLabel, QLineEdit, QMessageBox, QPushButton,
    QPlainTextEdit, QScrollArea, QTextEdit, QVBoxLayout, QWidget,
)
from qgis.core import QgsProject, QgsRasterLayer, QgsVectorLayer


# Each field is (key, label, default value, picker type).
OPERATIONS = {
    "object_detection": ("객체탐지", "Grounding DINO로 객체 후보를 탐지합니다. CRS와 지리참조가 있는 영상이 필요합니다. 결과는 EPSG:4326 GeoJSON으로 저장하며 정확도는 별도 검증해야 합니다. 첫 실행 시 모델을 다운로드합니다.", [
        ("input", "입력 영상", "", "file"),
        ("prompt", "탐지 대상", "building. car.", None),
        ("threshold", "신뢰도 임계값", "0.3", None),
    ], "GeoJSON (*.geojson)", "detected.geojson"),
    "image_classification": ("영상분류", "영상 전체의 분류 결과를 JSON으로 저장합니다. 기본 모델은 일반 ImageNet 모델입니다. 토지피복 픽셀 분류는 의미론적 분할 패널을 사용하십시오.", [
        ("input", "입력 영상", "", "file"),
        ("model", "Hugging Face 모델", "google/vit-base-patch16-224", None),
    ], "JSON (*.json)", "classification.json"),
    "pixel_regression": ("픽셀 회귀", "GeoAI PixelRegressionModel 형식의 학습된 Lightning 체크포인트가 필요합니다.", [
        ("input", "입력 래스터", "", "file"),
        ("model", "모델 체크포인트", "", "file"),
        ("tile_size", "타일 크기", "256", None),
        ("overlap", "중첩 크기", "64", None),
    ], "GeoTIFF (*.tif)", "regression.tif"),
    "stac_download": ("위성영상 다운로드", "Microsoft Planetary Computer의 STAC 자산을 검색해 지정 폴더에 저장합니다.", [
        ("collection", "컬렉션", "sentinel-2-l2a", None),
        ("bbox", "경계(서,남,동,북)", "", None),
        ("date_range", "기간", "2024-01-01/2024-12-31", None),
        ("assets", "자산 키", "visual", None),
        ("max_items", "최대 장면 수", "1", None),
    ], "directory", ""),
    "cloud_mask": ("구름 마스크", "OmniCloudMask가 필요하며 입력 밴드 번호를 영상 구성에 맞게 지정해야 합니다.", [
        ("input", "입력 래스터", "", "file"),
        ("red", "빨강 밴드", "1", None),
        ("green", "초록 밴드", "2", None),
        ("nir", "근적외선 밴드", "3", None),
    ], "GeoTIFF (*.tif)", "cloud_mask.tif"),
    "temporal_composite": ("시계열 합성", "같은 격자로 정합한 영상의 픽셀별 합성영상을 만듭니다. 여러 파일을 선택하십시오.", [
        ("paths", "입력 영상 목록", "", "files"),
        ("method", "합성 방식", "median", None),
    ], "GeoTIFF (*.tif)", "composite.tif"),
    "super_resolution": ("초해상도", "OpenSR 기반 Sentinel-2 RGB+NIR 4배 복원입니다. opensr-model과 모델 다운로드가 필요합니다.", [
        ("input", "입력 래스터", "", "file"),
        ("bands", "R,G,B,NIR 밴드", "1,2,3,4", None),
        ("steps", "샘플링 단계", "50", None),
    ], "GeoTIFF (*.tif)", "super_resolution.tif"),
}


class AdvancedToolWorker(QThread):
    completed = pyqtSignal(dict)
    failed = pyqtSignal(str)
    progress = pyqtSignal(str)

    def __init__(self, params):
        super().__init__()
        self.params = params

    def run(self):
        try:
            from ..core.geoai_task_subprocess import run_geoai_task

            result = run_geoai_task("advanced_tool", self.params, self.progress.emit)
            self.completed.emit(result)
        except Exception as exc:
            self.failed.emit(str(exc))


class AdvancedToolsDockWidget(QDockWidget):
    def __init__(self, iface, parent=None):
        super().__init__("NaGeoAI - 추가 분석", parent)
        self.iface = iface
        self.worker = None
        self.fields = {}
        self.setAllowedAreas(Qt.DockWidgetArea.LeftDockWidgetArea | Qt.DockWidgetArea.RightDockWidgetArea)
        self._setup_ui()

    def _setup_ui(self):
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        body = QWidget()
        layout = QVBoxLayout(body)
        self.operation = QComboBox()
        for key, (name, *_rest) in OPERATIONS.items():
            self.operation.addItem(name, key)
        self.operation.currentIndexChanged.connect(self._build_fields)
        layout.addWidget(self.operation)
        self.description = QLabel()
        self.description.setWordWrap(True)
        layout.addWidget(self.description)
        self.form_widget = QWidget()
        self.form = QFormLayout(self.form_widget)
        layout.addWidget(self.form_widget)
        self.output = QLineEdit()
        self.output_button = QPushButton("저장 위치...")
        self.output_button.clicked.connect(self._browse_output)
        row = QHBoxLayout()
        row.addWidget(self.output)
        row.addWidget(self.output_button)
        layout.addLayout(row)
        self.add_to_map = QCheckBox("공간 결과를 지도에 추가")
        self.add_to_map.setChecked(True)
        layout.addWidget(self.add_to_map)
        self.run_button = QPushButton("실행")
        self.run_button.clicked.connect(self._run)
        layout.addWidget(self.run_button)
        self.log = QTextEdit()
        self.log.setReadOnly(True)
        layout.addWidget(self.log)
        scroll.setWidget(body)
        self.setWidget(scroll)
        self._build_fields()

    def _build_fields(self):
        key = self.operation.currentData()
        name, description, definitions, output_type, default_output = OPERATIONS[key]
        self.description.setText(description)
        while self.form.rowCount():
            self.form.removeRow(0)
        self.fields = {}
        for field_key, label, default, picker in definitions:
            edit = QPlainTextEdit(default) if picker == "files" else QLineEdit(default)
            if picker == "files":
                edit.setPlaceholderText("영상 파일을 줄마다 하나씩 입력하십시오.")
                edit.setFixedHeight(85)
            self.fields[field_key] = edit
            if picker:
                row = QHBoxLayout()
                row.addWidget(edit)
                button = QPushButton("선택...")
                button.clicked.connect(lambda _checked=False, e=edit, p=picker: self._browse_input(e, p))
                row.addWidget(button)
                container = QWidget()
                container.setLayout(row)
                self.form.addRow(label, container)
            else:
                self.form.addRow(label, edit)
        self.output.setPlaceholderText("출력 폴더" if output_type == "directory" else "출력 파일 경로")
        self.output.setText("")

    def _browse_input(self, edit, picker):
        if picker == "files":
            paths, _ = QFileDialog.getOpenFileNames(self, "영상 선택", "", "Raster (*.tif *.tiff)")
            if paths:
                edit.setPlainText("\n".join(paths))
        else:
            path, _ = QFileDialog.getOpenFileName(self, "파일 선택", "", "All files (*)")
            if path:
                edit.setText(path)

    def _browse_output(self):
        output_type = OPERATIONS[self.operation.currentData()][3]
        if output_type == "directory":
            path = QFileDialog.getExistingDirectory(self, "출력 폴더 선택")
        else:
            path, _ = QFileDialog.getSaveFileName(self, "출력 저장", self.output.text(), output_type)
        if path:
            self.output.setText(path)

    def _run(self):
        key = self.operation.currentData()
        if key == "super_resolution":
            from ..core.opensr_setup import quick_status
            from ..core.venv_manager import get_venv_site_packages

            status = quick_status(get_venv_site_packages())
            if not status["package"] or not status["checkpoint"]:
                QMessageBox.warning(
                    self, "OpenSR 설정 필요",
                    "opensr-model 또는 초해상도 모델이 준비되지 않았습니다. "
                    "NaGeoAI 메뉴의 '필수 환경·모델 설치'에서 누락된 항목을 설치하십시오.",
                )
                return
        output = self.output.text().strip()
        values = {
            name: (field.toPlainText() if isinstance(field, QPlainTextEdit) else field.text()).strip()
            for name, field in self.fields.items()
        }
        if not output or any(not value for value in values.values()):
            QMessageBox.warning(self, "입력 확인", "모든 입력과 출력 경로를 지정하십시오.")
            return
        if key == "temporal_composite" and values["method"] not in {"median", "mean", "min", "max", "medoid"}:
            QMessageBox.warning(self, "입력 확인", "합성 방식은 median, mean, min, max, medoid 중 하나여야 합니다.")
            return
        self.run_button.setEnabled(False)
        self.log.append(f"{OPERATIONS[key][0]} 시작...")
        self.worker = AdvancedToolWorker({"operation": key, "inputs": values, "output": output})
        self.worker.progress.connect(self.log.append)
        self.worker.completed.connect(self._completed)
        self.worker.failed.connect(self._failed)
        self.worker.start()

    def _completed(self, result):
        self.run_button.setEnabled(True)
        self.log.append(result.get("summary", "완료"))
        self.log.append(result.get("output", ""))
        if result.get("output_crs"):
            self.log.append(f"좌표계: {result.get('source_crs')} → {result['output_crs']}")
        if result.get("count") == 0:
            self.log.append("후보가 0건이므로 빈 결과를 지도에 추가하지 않습니다.")
            return
        if not self.add_to_map.isChecked():
            return
        paths = result.get("files") or [result.get("output", "")]
        for path in paths:
            if not os.path.isfile(path):
                continue
            if path.lower().endswith((".tif", ".tiff")):
                layer = QgsRasterLayer(path, os.path.basename(path))
            elif path.lower().endswith((".geojson", ".gpkg", ".shp")):
                layer = QgsVectorLayer(path, os.path.basename(path), "ogr")
            else:
                continue
            if layer.isValid():
                QgsProject.instance().addMapLayer(layer)

    def _failed(self, message):
        self.run_button.setEnabled(True)
        self.log.append(f"오류: {message}")
        QMessageBox.critical(self, "NaGeoAI 분석 오류", message)

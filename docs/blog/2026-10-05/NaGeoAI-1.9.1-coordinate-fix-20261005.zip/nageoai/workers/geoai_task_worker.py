#!/usr/bin/env python3
"""One-shot worker process for running geoai tasks outside the QGIS process."""

from __future__ import annotations

import json
import logging
import os
import sys
import traceback
from typing import Any, Callable, Dict

_PROTO_STDOUT = sys.stdout


def _emit(message: Dict[str, Any]) -> None:
    print(json.dumps(message), file=_PROTO_STDOUT, flush=True)


def _progress(message: str) -> None:
    _emit({"type": "progress", "message": message})


def _ok(result: Any) -> None:
    _emit({"type": "ok", "result": result})


def _error(message: str) -> None:
    _emit({"type": "error", "message": message})


class _ProgressStdout:
    """Capture printed output and re-emit line-by-line as progress events."""

    def __init__(self, callback: Callable[[str], None]):
        self._callback = callback
        self._buf = ""

    def write(self, text: str) -> int:
        self._buf += text
        while "\n" in self._buf:
            line, self._buf = self._buf.split("\n", 1)
            if line.strip():
                self._callback(line)
        return len(text)

    def flush(self) -> None:
        if self._buf.strip():
            self._callback(self._buf)
        self._buf = ""


class _ProgressLoggingHandler(logging.Handler):
    """Route logging output through the progress callback."""

    def __init__(self, callback: Callable[[str], None]):
        super().__init__()
        self._callback = callback

    def emit(self, record: logging.LogRecord) -> None:
        try:
            msg = self.format(record)
            self._callback(msg)
        except Exception:
            self.handleError(record)


def _run_with_progress(fn: Callable[[], Any]) -> Any:
    old_stdout = sys.stdout
    sys.stdout = _ProgressStdout(_progress)

    # Capture logging output (logger.info, etc.) that would otherwise be lost
    log_handler = _ProgressLoggingHandler(_progress)
    log_handler.setLevel(logging.INFO)
    root_logger = logging.getLogger()
    original_level = root_logger.level
    if root_logger.level > logging.INFO:
        root_logger.setLevel(logging.INFO)
    root_logger.addHandler(log_handler)

    try:
        return fn()
    finally:
        try:
            sys.stdout.flush()
        except Exception:
            pass
        sys.stdout = old_stdout
        root_logger.removeHandler(log_handler)
        root_logger.setLevel(original_level)


def _geoai():
    import geoai

    return geoai


def _driver_for_path(path: str):
    lower = path.lower()
    if lower.endswith(".geojson"):
        return "GeoJSON"
    if lower.endswith(".gpkg"):
        return "GPKG"
    if lower.endswith(".shp"):
        return "ESRI Shapefile"
    return None


def _task_train_segmentation_model(params: Dict[str, Any]) -> Dict[str, Any]:
    geoai = _geoai()
    _progress("Starting training...")
    _run_with_progress(lambda: geoai.train_segmentation_model(**params))
    model_path = os.path.join(params["output_dir"], "best_model.pth")
    return {"model_path": model_path}


def _task_train_instance_segmentation_model(params: Dict[str, Any]) -> Dict[str, Any]:
    geoai = _geoai()
    _progress("Starting Mask R-CNN training...")
    _run_with_progress(lambda: geoai.train_instance_segmentation_model(**params))
    model_path = os.path.join(params["output_dir"], "best_model.pth")
    return {"model_path": model_path}


def _task_export_geotiff_tiles(params: Dict[str, Any]) -> Dict[str, Any]:
    from geoai.utils.training import export_geotiff_tiles

    _progress("Exporting tiles...")
    _run_with_progress(lambda: export_geotiff_tiles(**params))
    return {"output_dir": params["out_folder"]}


def _task_semantic_segmentation(params: Dict[str, Any]) -> Dict[str, Any]:
    geoai = _geoai()
    _progress("Running inference...")
    _run_with_progress(lambda: geoai.semantic_segmentation(**params))
    return {"output_path": params["output_path"]}


def _task_instance_segmentation(params: Dict[str, Any]) -> Dict[str, Any]:
    geoai = _geoai()
    _progress("Running instance segmentation inference...")
    _run_with_progress(lambda: geoai.instance_segmentation(**params))
    return {"output_path": params["output_path"]}


def _task_clip_raster_by_bbox(params: Dict[str, Any]) -> Dict[str, Any]:
    from geoai.utils.raster import clip_raster_by_bbox

    _progress("Clipping raster to inference range...")
    output_path = clip_raster_by_bbox(**params)
    return {"output_path": output_path}


def _task_raster_to_vector(params: Dict[str, Any]) -> Dict[str, Any]:
    from geoai.utils.raster import raster_to_vector

    mask_path = params["mask_path"]
    output_path = params["output_path"]
    min_area = params.get("min_area") or 0
    output_format = params.get("output_format", "geojson")
    simplify_tolerance = params.get("simplify_tolerance")

    _progress("Converting raster to vector...")
    raster_to_vector(
        mask_path,
        output_path=output_path,
        min_area=min_area,
        simplify_tolerance=simplify_tolerance,
        output_format=output_format,
    )
    return {"output_path": output_path}


def _task_vectorize_mask(params: Dict[str, Any]) -> Dict[str, Any]:
    from geoai.utils.geometry import orthogonalize
    from geoai.utils.vector import add_geometric_properties

    mask_path = params["mask_path"]
    output_path = params["output_path"]
    epsilon = params.get("epsilon", 2.0)
    min_area = params.get("min_area")

    _progress("Vectorizing mask...")
    gdf = orthogonalize(mask_path, output_path, epsilon=epsilon)

    if min_area is not None and min_area > 0:
        _progress(f"Filtering by area (min: {min_area})...")
        gdf = add_geometric_properties(gdf, area_unit="m2")
        gdf = gdf[gdf["area_m2"] >= min_area]
        driver = _driver_for_path(output_path)
        gdf.to_file(output_path, driver=driver)

    return {"output_path": output_path}


def _task_smooth_vector(params: Dict[str, Any]) -> Dict[str, Any]:
    from geoai.utils.raster import raster_to_vector
    from geoai.utils.vector import smooth_vector

    mask_path = params["mask_path"]
    output_path = params["output_path"]
    smooth_iterations = params.get("smooth_iterations", 3)
    min_area = params.get("min_area")
    simplify_tolerance = params.get("simplify_tolerance")

    _progress("Converting raster to vector...")
    min_area_value = min_area if min_area is not None else 0
    gdf = raster_to_vector(
        mask_path,
        min_area=min_area_value,
        simplify_tolerance=simplify_tolerance,
    )

    _progress(f"Smoothing vector (iterations: {smooth_iterations})...")
    smooth_vector(
        gdf,
        smooth_iterations=smooth_iterations,
        output_path=output_path,
    )
    return {"output_path": output_path}


def _task_segment_water(params: Dict[str, Any]) -> Dict[str, Any]:
    geoai = _geoai()
    _progress("Starting water segmentation...")
    result = _run_with_progress(lambda: geoai.segment_water(**params))

    input_path = params["input_path"]
    output_raster = params.get("output_raster")
    output_vector = params.get("output_vector") or ""

    if isinstance(result, str):
        final_raster = result
    elif output_raster:
        final_raster = output_raster
    else:
        stem = os.path.splitext(input_path)[0]
        final_raster = f"{stem}_water_mask.tif"

    return {"output_raster": final_raster, "output_vector": output_vector}


def _task_detect_raster_change(params: Dict[str, Any]) -> Dict[str, Any]:
    import importlib.util
    from pathlib import Path

    module_path = Path(__file__).resolve().parents[1] / "core" / "change_detection.py"
    spec = importlib.util.spec_from_file_location("nageoai_change_detection", module_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load change detection module: {module_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return _run_with_progress(lambda: module.detect_raster_change(**params, progress=_progress))


def _task_advanced_tool(params: Dict[str, Any]) -> Dict[str, Any]:
    """Run one of the additional GeoAI workflows with JSON-safe results."""
    from pathlib import Path

    operation = params["operation"]
    output = params.get("output", "")
    inputs = params.get("inputs", {})
    if not output:
        raise ValueError("Output path is required")
    if operation != "stac_download" and os.path.exists(output):
        raise FileExistsError(f"Output already exists: {output}")
    if operation != "stac_download":
        paths = ([line.strip() for line in inputs.get("paths", "").splitlines() if line.strip()]
                 if operation == "temporal_composite" else [inputs.get("input", "")])
        for path in paths:
            if not os.path.isfile(path):
                raise FileNotFoundError(f"Input file not found: {path}")
        if operation == "pixel_regression" and not os.path.isfile(inputs.get("model", "")):
            raise FileNotFoundError(f"Model checkpoint not found: {inputs.get('model', '')}")
        Path(output).parent.mkdir(parents=True, exist_ok=True)
    _progress(f"Starting {operation}...")

    if operation == "object_detection":
        from geoai.auto import object_detection
        import importlib.util

        module_path = Path(__file__).resolve().parents[1] / "core" / "detection_georeference.py"
        spec = importlib.util.spec_from_file_location("nageoai_detection_georeference", module_path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Cannot load detection export module: {module_path}")
        exporter = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(exporter)

        result = _run_with_progress(lambda: object_detection(
            input_path=inputs["input"],
            text=inputs["prompt"],
            box_threshold=float(inputs.get("threshold", 0.3)),
        ))
        # Upstream exports boxes in pixel space without CRS. Do not load that
        # output in QGIS: export validated map coordinates ourselves instead.
        exported = exporter.write_georeferenced_detections(inputs["input"], result, output)
        for warning in exported["warnings"]:
            _progress(f"주의: {warning}")
        return exported

    if operation == "image_classification":
        from geoai.auto import image_classification

        result = _run_with_progress(lambda: image_classification(
            input_path=inputs["input"], model_name=inputs["model"]
        ))
        # The Hugging Face result may contain numpy/tensor values.
        import json

        Path(output).parent.mkdir(parents=True, exist_ok=True)
        with open(output, "w", encoding="utf-8") as report:
            json.dump(result, report, ensure_ascii=False, indent=2,
                      default=lambda value: value.tolist() if hasattr(value, "tolist") else str(value),
                      allow_nan=False)
        return {"output": output, "summary": str(result)[:500]}

    if operation == "pixel_regression":
        from geoai.timm_regress import PixelRegressionModel, predict_raster

        model = PixelRegressionModel.load_from_checkpoint(inputs["model"])
        _run_with_progress(lambda: predict_raster(
            model, inputs["input"], output,
            tile_size=int(inputs.get("tile_size", 256)),
            overlap=int(inputs.get("overlap", 64)),
        ))
        return {"output": output, "summary": "Pixel regression complete"}

    if operation == "stac_download":
        from geoai.download import pc_stac_download, pc_stac_search

        bbox = [float(v.strip()) for v in inputs["bbox"].split(",")]
        if len(bbox) != 4 or not (bbox[0] < bbox[2] and bbox[1] < bbox[3]):
            raise ValueError("BBOX must contain west,south,east,north")
        items = _run_with_progress(lambda: pc_stac_search(
            collection=inputs["collection"], bbox=bbox,
            time_range=inputs["date_range"], max_items=int(inputs.get("max_items", 1)),
        ))
        if not items:
            return {"output": output, "summary": "No matching STAC items"}
        assets = [value.strip() for value in inputs["assets"].split(",") if value.strip()]
        if not assets:
            raise ValueError("Enter at least one STAC asset key")
        result = _run_with_progress(lambda: pc_stac_download(
            items, output_dir=output, assets=assets, max_workers=1,
        ))
        paths = [path for item in result.values() for path in item.values() if path]
        return {"output": output, "files": paths, "summary": f"Downloaded {len(paths)} asset(s)"}

    if operation == "cloud_mask":
        from geoai.tools.cloudmask import predict_cloud_mask_from_raster

        _run_with_progress(lambda: predict_cloud_mask_from_raster(
            inputs["input"], output,
            red_band=int(inputs.get("red", 1)),
            green_band=int(inputs.get("green", 2)),
            nir_band=int(inputs.get("nir", 3)),
        ))
        return {"output": output, "summary": "Cloud mask complete"}

    if operation == "temporal_composite":
        from geoai.tools.timeseries import create_temporal_composite

        paths = [line.strip() for line in inputs["paths"].splitlines() if line.strip()]
        if len(paths) < 2:
            raise ValueError("Select at least two aligned rasters")
        _run_with_progress(lambda: create_temporal_composite(
            paths, output, method=inputs.get("method", "median")
        ))
        return {"output": output, "summary": f"Composite created from {len(paths)} rasters"}

    if operation == "super_resolution":
        from geoai.tools.sr import super_resolution

        bands = [int(v.strip()) for v in inputs["bands"].split(",")]
        if len(bands) != 4:
            raise ValueError("Provide four RGB+NIR band numbers")
        _run_with_progress(lambda: super_resolution(
            input_lr_path=inputs["input"], output_sr_path=output,
            rgb_nir_bands=bands, sampling_steps=int(inputs.get("steps", 50)),
        ))
        return {"output": output, "summary": "Super-resolution complete"}

    raise ValueError(f"Unknown advanced operation: {operation}")


_TASKS = {
    "train_segmentation_model": _task_train_segmentation_model,
    "train_instance_segmentation_model": _task_train_instance_segmentation_model,
    "export_geotiff_tiles": _task_export_geotiff_tiles,
    "semantic_segmentation": _task_semantic_segmentation,
    "instance_segmentation": _task_instance_segmentation,
    "clip_raster_by_bbox": _task_clip_raster_by_bbox,
    "raster_to_vector": _task_raster_to_vector,
    "vectorize_mask": _task_vectorize_mask,
    "smooth_vector": _task_smooth_vector,
    "segment_water": _task_segment_water,
    "detect_raster_change": _task_detect_raster_change,
    "advanced_tool": _task_advanced_tool,
}


def main() -> int:
    line = sys.stdin.readline()
    if not line:
        _error("No request received")
        return 1

    try:
        req = json.loads(line)
    except json.JSONDecodeError as exc:
        _error(f"Invalid JSON request: {exc}")
        return 1

    action = req.get("action")
    params = req.get("params") or {}
    handler = _TASKS.get(action)
    if handler is None:
        _error(f"Unknown action: {action}")
        return 1

    try:
        result = handler(params)
        _ok(result)
        return 0
    except Exception as exc:
        traceback.print_exc(file=sys.stderr)
        _error(str(exc))
        return 1


if __name__ == "__main__":
    sys.exit(main())

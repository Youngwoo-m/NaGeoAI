"""Background worker thread for installing GeoAI dependencies.

Runs the full installation pipeline (download Python, create venv,
install packages) in a separate thread to keep the QGIS UI responsive.
"""

import traceback

from qgis.PyQt.QtCore import QThread, pyqtSignal


class DepsInstallWorker(QThread):
    """Worker thread that installs dependencies in the background.

    Signals:
        progress(int, str): Emitted with (percent, message) during install.
        finished(bool, str): Emitted with (success, message) when done.
    """

    progress = pyqtSignal(int, str)
    finished = pyqtSignal(bool, str)

    def __init__(self, cuda_enabled: bool = False, parent=None):
        """Initialize the worker.

        Args:
            cuda_enabled: Whether to install CUDA-enabled PyTorch.
            parent: Optional parent QObject.
        """
        super().__init__(parent)
        self._cancelled = False
        self._cuda_enabled = cuda_enabled

    def cancel(self):
        """Request cancellation of the installation."""
        self._cancelled = True

    def run(self):
        """Run the installation pipeline."""
        try:
            from ..core.venv_manager import (
                create_venv_and_install, get_venv_python_path,
                get_venv_site_packages, get_venv_status,
            )
            from ..core.uv_manager import get_uv_path
            from ..core.opensr_setup import ensure_opensr_ready

            ready, _ = get_venv_status()
            if ready:
                self.progress.emit(50, "기본 GeoAI 환경이 이미 설치되어 있어 건너뜁니다")
                success, message = True, "기본 GeoAI 환경 준비 완료"
            else:
                success, message = create_venv_and_install(
                    progress_callback=lambda p, m: self.progress.emit(int(p * 0.5), m),
                    cancel_check=lambda: self._cancelled,
                    cuda_enabled=self._cuda_enabled,
                )
            if success and not self._cancelled:
                success, message = ensure_opensr_ready(
                    get_venv_python_path(), get_venv_site_packages(),
                    uv_path=get_uv_path(),
                    progress=lambda p, m: self.progress.emit(50 + int(p * 0.5), m),
                    cancelled=lambda: self._cancelled,
                )
            self.finished.emit(success, message)
        except Exception as e:
            error_msg = f"{str(e)}\n{traceback.format_exc()}"
            self.finished.emit(False, error_msg)

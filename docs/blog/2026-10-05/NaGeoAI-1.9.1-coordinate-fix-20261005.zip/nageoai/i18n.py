"""Lightweight Korean localization for the GeoAI QGIS plugin.

The plugin historically embedded English UI strings directly in Python instead
of using Qt ``.ts/.qm`` catalogs.  This module provides a non-invasive Korean
translation layer while keeping model names, file formats, and API values
unchanged.
"""

from __future__ import annotations


KO = {
    # Runtime error and status messages (added 2026-09-07)
    "Model: Failed to load": "모델: 불러오기 실패",
    "Image: Failed to export": "영상: 내보내기 실패",
    "Image: Failed to set": "영상: 설정 실패",
    "Image: Failed to set (invalid layer)": "영상: 설정 실패 (레이어가 올바르지 않음)",
    "Could not detect GPU.\nCPU mode will be used.": "GPU를 감지하지 못했습니다.\nCPU 모드로 실행됩니다.",
    "NaGeoAI Upstream Update": "NaGeoAI 상위 저장소 업데이트",
    # Plugin menu and common actions
    "GeoAI Toolbar": "GeoAI 도구 모음",
    "NaGeoAI Toolbar": "NaGeoAI 도구 모음",
    "NaGeoAI - Setup": "NaGeoAI - 설치",
    "NaGeoAI - Moondream": "NaGeoAI - Moondream",
    "NaGeoAI - Semantic Segmentation": "NaGeoAI - 의미론적 분할",
    "NaGeoAI - Instance Segmentation": "NaGeoAI - 인스턴스 분할",
    "NaGeoAI Diagnostics Report": "NaGeoAI 진단 보고서",
    "Tree Segmentation": "수목 분할",
    "Water Segmentation": "수체 분할",
    "Change Detection": "변화탐지",
    "Additional Analysis": "추가 분석",
    "Object detection, classification, regression, imagery download, cloud and time series, super-resolution": "객체탐지·영상분류·픽셀 회귀·영상 다운로드·구름 및 시계열·초해상도",
    "Compare two aligned rasters and create a change mask": "정합된 두 래스터를 비교하여 변화 마스크를 생성합니다.",
    "Moondream VLM": "Moondream 시각언어 모델",
    "Segment Anything": "범용 객체 분할(SAM)",
    "Semantic Segmentation": "의미론적 분할",
    "Instance Segmentation": "인스턴스 분할",
    "Clear GPU Memory": "GPU 메모리 정리",
    "Check for Updates...": "업데이트 확인...",
    "Generate Diagnostics Report...": "진단 보고서 생성...",
    "About GeoAI": "GeoAI 정보",
    "About NaGeoAI": "NaGeoAI 정보",
    "About NaGeoAI Plugin": "NaGeoAI 플러그인 정보",
    "Toggle Tree Segmentation panel (tree crown detection and forest analysis)": "수관 탐지 및 산림 분석 패널을 열거나 닫습니다.",
    "Toggle Water Segmentation panel (OmniWaterMask water body detection)": "OmniWaterMask 수체 탐지 패널을 열거나 닫습니다.",
    "Toggle Moondream Vision-Language Model panel": "Moondream 시각언어 모델 패널을 열거나 닫습니다.",
    "Toggle Segment Anything panel (supports SAM1, SAM2, and SAM3 models)": "SAM1, SAM2, SAM3 객체 분할 패널을 열거나 닫습니다.",
    "Toggle Semantic Segmentation Training & Inference panel": "의미론적 분할 학습 및 추론 패널을 열거나 닫습니다.",
    "Toggle Instance Segmentation panel (Mask R-CNN training & inference)": "Mask R-CNN 학습 및 추론 패널을 열거나 닫습니다.",
    "Release GPU memory and clear CUDA cache": "GPU 메모리와 CUDA 캐시를 정리합니다.",
    "Check for plugin updates from GitHub": "GitHub에서 플러그인 업데이트를 확인합니다.",
    "Generate a Markdown diagnostics report for GitHub issues": "GitHub 이슈용 Markdown 진단 보고서를 생성합니다.",
    "About GeoAI Plugin": "GeoAI 플러그인 정보",

    # Windows and tabs
    "GeoAI - Setup": "GeoAI - 설치",
    "GeoAI - Moondream": "GeoAI - Moondream",
    "GeoAI - Semantic Segmentation": "GeoAI - 의미론적 분할",
    "GeoAI - Instance Segmentation": "GeoAI - 인스턴스 분할",
    "GeoAI Diagnostics Report": "GeoAI 진단 보고서",
    "GeoAI Plugin Update": "GeoAI 플러그인 업데이트",
    "GeoAI Plugin Update Checker": "GeoAI 플러그인 업데이트 확인",
    "Model": "모델",
    "Predict": "예측",
    "Output": "출력",
    "Text": "텍스트",
    "Interactive": "대화형",
    "Batch": "일괄 처리",
    "Log": "로그",
    "1. Create Data": "1. 데이터 생성",
    "2. Train": "2. 학습",
    "3. Inference": "3. 추론",

    # Common controls
    "Model Settings": "모델 설정",
    "Model:": "모델:",
    "Revision:": "리비전:",
    "Device:": "장치:",
    "Mode:": "모드:",
    "Format:": "형식:",
    "Input": "입력",
    "Input Data": "입력 데이터",
    "Input Layer": "입력 레이어",
    "Image Input": "영상 입력",
    "Training Data": "학습 데이터",
    "Parameters": "매개변수",
    "Settings": "설정",
    "Output Settings": "출력 설정",
    "Output Format": "출력 형식",
    "Inference Range": "추론 범위",
    "Full raster": "전체 래스터",
    "Draw Range": "범위 그리기",
    "Clear": "지우기",
    "Close": "닫기",
    "Cancel": "취소",
    "Refresh": "새로 고침",
    "Save": "저장",
    "Reset": "초기화",
    "Results": "결과",
    "Detection Results": "탐지 결과",
    "Add to map": "지도에 추가",
    "Add result to map": "결과를 지도에 추가",
    "Add results to map": "결과를 지도에 추가",
    "Load Model": "모델 불러오기",
    "Run": "실행",
    "Ready": "준비됨",
    "Failed!": "실패했습니다.",
    "Model not loaded": "모델을 불러오지 않음",
    "Model: Not loaded": "모델: 불러오지 않음",
    "Image: Not set": "영상: 설정되지 않음",
    "Loading model...": "모델을 불러오는 중...",
    "Loading model (CPU fallback)...": "모델을 불러오는 중(CPU 대체 실행)...",
    "Processing...": "처리 중...",
    "Setting image...": "영상을 설정하는 중...",
    "Or select image file...": "또는 영상 파일 선택...",
    "Or select raster file...": "또는 래스터 파일 선택...",
    "Or select vector file...": "또는 벡터 파일 선택...",
    "Or path to image file...": "또는 영상 파일 경로...",
    "Or path to raster...": "또는 래스터 경로...",
    "Or path to vector...": "또는 벡터 경로...",
    "Output directory...": "출력 폴더...",
    "Images directory...": "영상 폴더...",
    "Labels directory...": "라벨 폴더...",
    "Vector output...": "벡터 출력 경로...",
    "Output mask path...": "출력 마스크 경로...",
    "Model path (.pth)...": "모델 경로(.pth)...",

    # Data creation, training, and inference
    "Tile Settings": "타일 설정",
    "Export Tiles": "타일 내보내기",
    "Export Training Data": "학습 데이터 내보내기",
    "Export Training Tiles": "학습 타일 내보내기",
    "Export": "내보내기",
    "Start Training": "학습 시작",
    "Run Inference": "추론 실행",
    "Vectorize": "벡터화",
    "Vectorize (Optional)": "벡터화(선택 사항)",
    "Fine-tuning (Optional)": "미세 조정(선택 사항)",
    "Save training curves plot": "학습 곡선 그래프 저장",
    "Save prediction visualizations": "예측 시각화 저장",
    "Resume training (load optimizer state)": "학습 재개(옵티마이저 상태 불러오기)",
    "Freeze encoder (train decoder only)": "인코더 고정(디코더만 학습)",
    "Use threshold": "임계값 사용",
    "Save probability map": "확률 지도 저장",
    "Probability output path...": "확률 지도 출력 경로...",
    "Number of classes including background": "배경을 포함한 클래스 수",
    "Confidence threshold for detections": "탐지 신뢰도 임계값",
    "Douglas-Peucker tolerance for orthogonalization (suitable for buildings)": "직교화용 Douglas-Peucker 허용오차(건물에 적합)",
    "Douglas-Peucker simplification tolerance for orthogonalization (suitable for buildings)": "직교화용 Douglas-Peucker 단순화 허용오차(건물에 적합)",
    "Number of smoothing iterations (suitable for natural features like water)": "평활화 반복 횟수(수체 등 자연 객체에 적합)",
    "Number of smoothing iterations (suitable for natural features like water, vegetation)": "평활화 반복 횟수(수체·식생 등 자연 객체에 적합)",

    # SAM
    "Enable Interactive Mode (Point/Box Prompts)": "대화형 모드 사용(점/박스 프롬프트)",
    "Set Image from Layer": "레이어에서 영상 설정",
    "Set Image from File": "파일에서 영상 설정",
    "Use custom RGB bands": "사용자 지정 RGB 밴드 사용",
    "Text-Based Segmentation": "텍스트 기반 분할",
    "e.g., tree, building, road...": "예: 나무, 건물, 도로...",
    "Segment by Text": "텍스트로 분할",
    "Point Prompts": "점 프롬프트",
    "Add Foreground Points": "전경점 추가",
    "Add Background Points": "배경점 추가",
    "Clear Points": "점 지우기",
    "Segment by Points": "점으로 분할",
    "Box Prompts": "박스 프롬프트",
    "Draw Box": "박스 그리기",
    "Box: Not set": "박스: 설정되지 않음",
    "Clear Box": "박스 지우기",
    "Segment by Box": "박스로 분할",
    "Create Points Interactively": "대화형으로 점 생성",
    "Add Points on Map": "지도에 점 추가",
    "Points: 0": "점: 0",
    "Or Load Points from File/Layer": "또는 파일/레이어에서 점 불러오기",
    "Batch Settings": "일괄 처리 설정",
    "Unique values for each object": "객체별 고유값 부여",
    "Run Batch Segmentation": "일괄 분할 실행",
    "Vector Processing Options (Vector Only)": "벡터 처리 옵션(벡터 전용)",
    "Minimum area filter - polygons smaller than this will be removed": "최소 면적 필터 - 이 값보다 작은 폴리곤은 제거됩니다.",
    "Save Masks": "마스크 저장",
    "No objects found. Try a different prompt.": "객체를 찾지 못했습니다. 다른 프롬프트를 사용하십시오.",
    "No objects found. Try different points.": "객체를 찾지 못했습니다. 다른 점을 지정하십시오.",
    "No objects found. Try a different box.": "객체를 찾지 못했습니다. 다른 박스를 지정하십시오.",

    # DeepForest
    "Prediction Mode": "예측 모드",
    "Large Tile Settings": "대용량 타일 설정",
    "Large Tile Settings (CPU)": "대용량 타일 설정(CPU)",
    "Filtering": "필터링",
    "Run Prediction": "예측 실행",
    "Save Results": "결과 저장",
    "Auto-show results after prediction": "예측 후 결과 자동 표시",
    "Loading model...": "모델을 불러오는 중...",
    "Running prediction...": "예측 실행 중...",
    "Prediction failed!": "예측에 실패했습니다.",
    "No detections found.": "탐지된 객체가 없습니다.",
    '<b>Tree Segmentation</b> — <a href="https://github.com/weecology/DeepForest">DeepForest</a>': '<b>수목 분할</b> — <a href="https://github.com/weecology/DeepForest">DeepForest</a>',
    "Use Large Tile for high-resolution or very large imagery; it processes smaller patches and exposes tile settings below.": "고해상도 또는 대용량 영상에는 대용량 타일 모드를 사용하십시오. 영상을 작은 패치로 나누어 처리하며 아래에서 타일 설정을 조정할 수 있습니다.",
    "Number of patches to process simultaneously.\nHigher values speed up prediction but use more GPU memory.\nRecommended: 1 for <=8 GB GPU, 2 for 8-12 GB, 4 for >=12 GB.\nReduce if you get out-of-memory errors.": "동시에 처리할 패치 수입니다.\n값이 크면 예측 속도가 빨라지지만 GPU 메모리를 더 사용합니다.\n권장값: GPU 8GB 이하는 1, 8~12GB는 2, 12GB 이상은 4입니다.\n메모리 부족 오류가 발생하면 값을 줄이십시오.",
    "batch: fastest, loads entire image into GPU memory (>=12 GB GPU)\nsingle: loads full image to RAM, processes patches one at a time (8-12 GB GPU)\nwindow: most memory-efficient, reads only needed windows from disk (<=8 GB GPU)\nUse 'window' if you experience out-of-memory errors.": "batch: 가장 빠르며 전체 영상을 GPU 메모리에 적재(GPU 12GB 이상)\nsingle: 전체 영상을 RAM에 적재하고 패치를 하나씩 처리(GPU 8~12GB)\nwindow: 메모리 효율이 가장 높으며 필요한 영역만 디스크에서 읽음(GPU 8GB 이하)\n메모리 부족 오류가 발생하면 window를 사용하십시오.",
    "Automatically save and display results on the map after running prediction": "예측 실행 후 결과를 자동으로 저장하고 지도에 표시합니다.",
    "Output file path (optional)...": "출력 파일 경로(선택 사항)...",
    "Patch Size:": "패치 크기:",
    "Patch Overlap:": "패치 중첩:",
    "IoU Threshold:": "IoU 임계값:",
    "Batch Size:": "배치 크기:",
    "Dataloader Strategy:": "데이터 로더 방식:",
    "Score Threshold:": "점수 임계값:",
    "Exporting GeoPackage raster...": "GeoPackage 래스터를 내보내는 중...",

    # Water segmentation
    "Run Water Segmentation": "수체 분할 실행",
    "Sensor / Band Order": "센서 / 밴드 순서",
    "Processing Settings": "처리 설정",
    "OSM Refinement": "OSM 기반 보정",
    "Use OSM Water features": "OSM 수체 객체 사용",
    "Use OSM Buildings (reduce false positives)": "OSM 건물 사용(오탐 감소)",
    "Use OSM Roads (reduce false positives)": "OSM 도로 사용(오탐 감소)",
    "Vectorization (Optional)": "벡터화(선택 사항)",
    "Generate vector polygons": "벡터 폴리곤 생성",
    "Smooth polygons": "폴리곤 평활화",
    "Water mask output path (.tif)": "수체 마스크 출력 경로(.tif)",
    "Water polygons output (.gpkg, .geojson, .shp)": "수체 폴리곤 출력(.gpkg, .geojson, .shp)",
    "Running water segmentation...": "수체 분할 실행 중...",
    "Segmentation complete!": "분할이 완료되었습니다.",
    "Segmentation failed": "분할에 실패했습니다.",
    '<b>Water Segmentation</b> — <a href="https://github.com/DPIRD-DMA/OmniWaterMask">OmniWaterMask</a>': '<b>수체 분할</b> — <a href="https://github.com/DPIRD-DMA/OmniWaterMask">OmniWaterMask</a>',
    "Inference precision. float16 is faster but requires GPU support.": "추론 정밀도입니다. float16은 빠르지만 GPU 지원이 필요합니다.",
    "Preset:": "프리셋:",
    "Dtype:": "자료형:",
    "Overlap Size:": "중첩 크기:",
    "No Data Value:": "NoData 값:",
    "Min Size (pixels):": "최소 크기(픽셀):",
    "Smooth Iterations:": "평활화 반복 횟수:",
    "Raster:": "래스터:",
    "Vector:": "벡터:",

    # Moondream
    "Load Image": "영상 불러오기",
    "No image loaded": "불러온 영상 없음",
    "Analysis": "분석",
    "Enter prompt...": "프롬프트 입력...",
    "Add results to map": "결과를 지도에 추가",
    "Export image tiles with detection annotations.\nRequires: loaded image and detection results.": "탐지 주석이 포함된 영상 타일을 내보냅니다.\n필요 조건: 영상과 탐지 결과가 준비되어야 합니다.",
    "Result Color": "결과 색상",
    "Not needed for caption mode": "영상 설명 모드에서는 필요하지 않음",
    "Ask a question about the image...": "영상에 관한 질문 입력...",
    "Object type (e.g., building, car)...": "객체 유형(예: 건물, 자동차)...",
    "Object description to locate...": "찾을 객체 설명...",
    'Device to run the model on. "Auto" will select CUDA if available, otherwise CPU.': "모델 실행 장치입니다. 자동을 선택하면 CUDA 사용 가능 시 CUDA를 사용하고, 그렇지 않으면 CPU를 사용합니다.",
    "Layer:": "레이어:",

    # Setup, diagnostics, and update
    "Welcome": "환영합니다",
    "GPU Detection": "GPU 감지",
    "Detecting GPU...": "GPU를 감지하는 중...",
    "Install Dependencies": "필수 패키지 설치",
    "Install Dependencies...": "필수 환경·모델 설치...",
    "Reinstall Dependencies": "필수 패키지 다시 설치",
    "Starting installation...": "설치를 시작하는 중...",
    "Installation complete!": "설치가 완료되었습니다.",
    "GeoAI needs to install AI dependencies before you can use it.\n\nThis is a one-time setup that will:\n  • Download a Python runtime (~50 MB)\n  • Download a fast package installer (~15 MB)\n  • Install AI packages (~1–3 GB)": "GeoAI를 사용하려면 AI 필수 패키지를 설치해야 합니다.\n\n최초 한 번만 다음 항목을 설치합니다.\n  • Python 실행 환경 다운로드(약 50MB)\n  • 고속 패키지 설치 도구 다운로드(약 15MB)\n  • AI 패키지 설치(약 1~3GB)",
    "NaGeoAI needs to install AI dependencies before you can use it.\n\nThis is a one-time setup that will:\n  • Download a Python runtime (~50 MB)\n  • Download a fast package installer (~15 MB)\n  • Install AI packages (~1–3 GB)": "NaGeoAI를 사용하려면 AI 필수 패키지를 설치해야 합니다.\n\n최초 한 번만 다음 항목을 설치합니다.\n  • Python 실행 환경 다운로드(약 50MB)\n  • 고속 패키지 설치 도구 다운로드(약 15MB)\n  • AI 패키지 설치(약 1~3GB)",
    '<small>If you encounter issues, please check the <a href="https://opengeoai.org/qgis_plugin/">documentation</a> or report a bug on <a href="https://github.com/opengeos/geoai/issues">GitHub</a>.</small>': '<small>문제가 발생하면 <a href="https://opengeoai.org/qgis_plugin/">문서</a>를 확인하거나 <a href="https://github.com/opengeos/geoai/issues">GitHub</a>에 오류를 보고하십시오.</small>',
    "Could not detect NVIDIA GPU.\nCUDA will not be enabled. Apple Silicon MPS may still be used at runtime if available.": "NVIDIA GPU를 감지하지 못했습니다.\nCUDA를 사용하지 않습니다. Apple Silicon에서는 사용 가능한 경우 MPS를 사용할 수 있습니다.",
    "Could not detect GPU.\nCPU mode will be used.": "GPU를 감지하지 못했습니다.\nCPU 모드로 실행합니다.",
    "Copy Markdown": "Markdown 복사",
    "Save Markdown...": "Markdown 저장...",
    "Version Information": "버전 정보",
    "Not checked": "확인하지 않음",
    "Changelog": "변경 이력",
    "Check for Updates": "업데이트 확인",
    "Download and Install Update": "업데이트 다운로드 및 설치",
    "Checking for updates...": "업데이트 확인 중...",
    "Checking...": "확인 중...",
    "Starting download...": "다운로드를 시작하는 중...",
    "Downloading and installing update...": "업데이트를 다운로드하고 설치하는 중...",
    "You are running the latest version!": "현재 최신 버전을 사용하고 있습니다.",
    "Your version appears to be newer than the released version. You may be running a development build.": "설치된 버전이 배포 버전보다 최신입니다. 개발 버전일 수 있습니다.",
    "Click 'Check for Updates' to check for new versions": "새 버전을 확인하려면 '업데이트 확인'을 누르십시오.",
    "Changelog will appear here after checking for updates...": "업데이트를 확인하면 변경 이력이 여기에 표시됩니다...",
    "Error": "오류",
    "Warning": "경고",

    # Detailed prompts and status labels
    "Export format for training data:\n- PASCAL_VOC: XML annotation files (default)\n- COCO: JSON annotation file (for instance segmentation)\n- YOLO: Text files with normalized coordinates": "학습 데이터 출력 형식:\n- PASCAL_VOC: XML 주석 파일(기본값)\n- COCO: JSON 주석 파일(인스턴스 분할용)\n- YOLO: 정규화 좌표 텍스트 파일",
    "Export format for training data:\n- PASCAL_VOC: XML annotation files\n- COCO: JSON annotation file\n- YOLO: Text files with normalized coordinates": "학습 데이터 출력 형식:\n- PASCAL_VOC: XML 주석 파일\n- COCO: JSON 주석 파일\n- YOLO: 정규화 좌표 텍스트 파일",
    "Export format for training data:\n- PASCAL_VOC: XML annotation files (semantic segmentation)\n- COCO: JSON annotation file (instance segmentation)\n- YOLO: Text files with normalized coordinates": "학습 데이터 출력 형식:\n- PASCAL_VOC: XML 주석 파일(의미론적 분할)\n- COCO: JSON 주석 파일(인스턴스 분할)\n- YOLO: 정규화 좌표 텍스트 파일",
    "Model (Mask R-CNN)": "모델(Mask R-CNN)",
    "Enable to specify custom bands for RGB display.\nUseful for multi-band GeoTIFF files (with more than 3 bands).\nExample: [4, 3, 2] for NIR-R-G false color composite.": "RGB 표시에 사용할 밴드를 직접 지정합니다.\n3개보다 많은 밴드를 가진 다중 밴드 GeoTIFF에 유용합니다.\n예: NIR-R-G 위색 합성은 [4, 3, 2]입니다.",
    "Red band index (1-based)": "빨강 밴드 번호(1부터 시작)",
    "Green band index (1-based)": "초록 밴드 번호(1부터 시작)",
    "Blue band index (1-based)": "파랑 밴드 번호(1부터 시작)",
    "e.g., EPSG:4326 (auto-detect if empty)": "예: EPSG:4326(비워 두면 자동 감지)",
    "Output raster file (optional)...": "출력 래스터 파일(선택 사항)...",
    "<i>Batch mode processes each point as a separate prompt, generating individual masks for each point.</i>": "<i>일괄 처리 모드는 각 점을 개별 프롬프트로 처리하여 점마다 별도 마스크를 생성합니다.</i>",
    "Auto-show results after segmentation": "분할 후 결과 자동 표시",
    "Automatically save and display results after running segmentation\nin the Text, Interactive, or Batch tabs": "텍스트·대화형·일괄 처리 탭에서 분할 실행 후\n결과를 자동으로 저장하고 표시합니다.",
    "Output file path (optional, uses temp file if empty)...": "출력 파일 경로(선택 사항, 비워 두면 임시 파일 사용)...",
    "Export output directory...": "출력 폴더...",
    "Export image tiles with segmentation masks.\nRequires: image set and segmentation results.": "분할 마스크가 포함된 영상 타일을 내보냅니다.\n필요 조건: 영상과 분할 결과가 준비되어야 합니다.",
    "-- Select from file instead --": "-- 파일에서 직접 선택 --",
    "Processing batch segmentation...": "일괄 분할 처리 중...",
    "Backend:": "백엔드:",
    "Confidence:": "신뢰도:",
    "Describe objects to segment:": "분할할 객체 설명:",
    "Min size:": "최소 크기:",
    "Max size:": "최대 크기:",
    "CRS:": "좌표계:",
    "Epsilon:": "엡실론:",
    "Iterations:": "반복 횟수:",
    "Min Area:": "최소 면적:",
    "Tile Size:": "타일 크기:",
    "Stride:": "이동 간격:",
    "Segmentation failed!": "분할에 실패했습니다.",
    "Path to pretrained model (.pth)...": "사전학습 모델 경로(.pth)...",
}


def ko(text: str) -> str:
    """Return the Korean UI translation while preserving unknown text."""
    if not isinstance(text, str) or not text:
        return text
    if text in KO:
        return KO[text]

    # Preserve dynamic values while translating common status prefixes.
    prefixes = {
        "Model: ": "모델: ",
        "Image: ": "영상: ",
        "Layer: ": "레이어: ",
        "Device: ": "장치: ",
        "Mode: ": "모드: ",
        "Format: ": "형식: ",
        "Error: ": "오류: ",
        "Failed to ": "실패: ",
    }
    for source, target in prefixes.items():
        if text.startswith(source):
            return target + text[len(source) :]
    return text


def translate_widget_tree(root) -> None:
    """Translate the visible strings of one plugin widget hierarchy."""
    try:
        from qgis.PyQt.QtWidgets import (
            QAbstractButton,
            QAction,
            QComboBox,
            QGroupBox,
            QLabel,
            QLineEdit,
            QTabWidget,
            QWidget,
        )
    except ImportError:
        return

    objects = [root]
    try:
        objects.extend(root.findChildren(QWidget))
        objects.extend(root.findChildren(QAction))
    except (AttributeError, RuntimeError):
        pass

    for obj in objects:
        try:
            if hasattr(obj, "windowTitle") and hasattr(obj, "setWindowTitle"):
                obj.setWindowTitle(ko(obj.windowTitle()))
            if isinstance(obj, (QLabel, QAbstractButton, QAction)):
                obj.setText(ko(obj.text()))
            if isinstance(obj, QGroupBox):
                obj.setTitle(ko(obj.title()))
            if isinstance(obj, QLineEdit):
                obj.setPlaceholderText(ko(obj.placeholderText()))
            if hasattr(obj, "toolTip") and hasattr(obj, "setToolTip"):
                obj.setToolTip(ko(obj.toolTip()))
            if hasattr(obj, "statusTip") and hasattr(obj, "setStatusTip"):
                obj.setStatusTip(ko(obj.statusTip()))
            if isinstance(obj, QTabWidget):
                for index in range(obj.count()):
                    obj.setTabText(index, ko(obj.tabText(index)))
            if isinstance(obj, QComboBox):
                for index in range(obj.count()):
                    obj.setItemText(index, ko(obj.itemText(index)))
        except (AttributeError, RuntimeError, TypeError):
            continue


def enable_korean(widget) -> None:
    """Schedule translation after a widget has finished constructing its UI."""
    try:
        from qgis.PyQt.QtCore import QTimer

        QTimer.singleShot(0, lambda: translate_widget_tree(widget))
    except (ImportError, RuntimeError):
        translate_widget_tree(widget)
